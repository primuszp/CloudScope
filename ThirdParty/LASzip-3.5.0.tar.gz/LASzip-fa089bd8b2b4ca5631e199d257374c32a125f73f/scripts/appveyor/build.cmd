nmake /f Makefile
